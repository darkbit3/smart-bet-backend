# Smart Betting System Backend

A modern, scalable Node.js/TypeScript backend API for the smart betting system.

## 🏗️ Architecture

This backend follows a clean, modular architecture with separation of concerns:

```
backend/
├── src/
│   ├── controllers/     # Request handlers and response logic
│   ├── services/        # Business logic and data processing
│   ├── models/          # Database models and schemas
│   ├── routes/          # API route definitions
│   ├── middleware/      # Custom middleware functions
│   ├── repositories/    # Data access layer
│   ├── validators/      # Input validation schemas
│   ├── utils/           # Utility functions and helpers
│   ├── config/          # Configuration files
│   ├── interfaces/      # TypeScript interfaces
│   ├── types/           # Custom type definitions
│   └── database/        # Database setup, migrations, seeds
├── tests/               # Test suites
├── docs/                # API documentation
├── logs/                # Application logs
├── uploads/             # File upload storage
└── scripts/             # Utility scripts
```

## 🚀 Quick Start

### Prerequisites
- Node.js >= 18.0.0
- PostgreSQL
- Redis (optional, for caching)

### Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```

3. Set up environment variables:
   ```bash
   cp .env.example .env
   # Edit .env with your configuration
   ```

4. Set up the database:
   ```bash
   npm run migrate
   npm run seed
   ```

5. Start the development server:
   ```bash
   npm run dev
   ```

## 📁 Project Structure

### Core Components

- **Controllers**: Handle HTTP requests and responses
- **Services**: Contain business logic and orchestrate data flow
- **Repositories**: Abstract data access and database operations
- **Models**: Define data structures and validation rules
- **Middleware**: Cross-cutting concerns (auth, validation, logging)
- **Routes**: Define API endpoints and map to controllers

### Key Features

- ✅ TypeScript for type safety
- ✅ Express.js framework
- ✅ PostgreSQL with Knex.js migrations
- ✅ JWT authentication
- ✅ Rate limiting
- ✅ Request validation with Joi
- ✅ Structured logging with Winston
- ✅ Comprehensive error handling
- ✅ API documentation
- ✅ Unit and integration tests
- ✅ Redis caching support
- ✅ File upload handling

## 🛠️ Available Scripts

- `npm run dev` - Start development server with hot reload
- `npm run build` - Build for production
- `npm start` - Start production server
- `npm test` - Run test suite
- `npm run test:watch` - Run tests in watch mode
- `npm run test:coverage` - Generate coverage report
- `npm run lint` - Run ESLint
- `npm run lint:fix` - Fix linting issues
- `npm run migrate` - Run database migrations
- `npm run seed` - Seed database with initial data
- `npm run db:reset` - Reset database (rollback, migrate, seed)

## 📚 API Documentation

API documentation will be available at `/api/docs` when running the server.

## 🧪 Testing

The project includes comprehensive test coverage:

- Unit tests for individual functions and classes
- Integration tests for API endpoints
- Database tests with test fixtures
- Mock external service dependencies

## 🔧 Configuration

Configuration is managed through environment variables. See `.env.example` for all available options.

## 🚀 Deployment

### Docker (Recommended)

```bash
# Build image
docker build -t smart-betting-backend .

# Run container
docker run -p 3000:3000 --env-file .env smart-betting-backend
```

### Traditional Deployment

1. Build the application: `npm run build`
2. Set production environment variables
3. Start the server: `npm start`

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Ensure all tests pass
6. Submit a pull request

## 📝 License

This project is licensed under the MIT License.
