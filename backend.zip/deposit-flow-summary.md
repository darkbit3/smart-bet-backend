# Deposit Flow Implementation Summary

## Overview
When a cashier deposits money to a player, the system updates multiple tables and maintains data integrity across the entire system.

## Database Tables Involved

### 1. Players Table
```sql
CREATE TABLE players (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username VARCHAR(30) UNIQUE NOT NULL,
  phone_number VARCHAR(15) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  balance DECIMAL(10,2) DEFAULT 0.00,
  withdrawable DECIMAL(10,2) DEFAULT 0.00,
  non_withdrawable DECIMAL(10,2) DEFAULT 0.00,
  bonus_balance DECIMAL(10,2) DEFAULT 0.00,
  status VARCHAR(20) DEFAULT 'active',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  created_by VARCHAR(50) DEFAULT NULL
);
```

### 2. Cashier_Users Table
```sql
CREATE TABLE cashier_users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username VARCHAR(50) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_by VARCHAR(50) NOT NULL,
  number_of_players INTEGER DEFAULT 0,
  balance DECIMAL(15,2) DEFAULT 0.00,
  status VARCHAR(20) DEFAULT 'active',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### 3. Transactions Table
```sql
CREATE TABLE transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  phonenumber TEXT NOT NULL,
  method TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('withdraw', 'deposit')),
  time DATETIME DEFAULT CURRENT_TIMESTAMP,
  old_balance REAL NOT NULL,
  new_balance REAL NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### 4. Cashier_Transactions Table
```sql
CREATE TABLE cashier_transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  cashier_id INTEGER NOT NULL,
  player_id INTEGER NOT NULL,
  transaction_type VARCHAR(20) NOT NULL CHECK (transaction_type IN ('deposit', 'withdrawal')),
  amount DECIMAL(10,2) NOT NULL,
  balance_before DECIMAL(10,2) NOT NULL,
  balance_after DECIMAL(10,2) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'failed')),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (cashier_id) REFERENCES cashier_users(id),
  FOREIGN KEY (player_id) REFERENCES players(id)
);
```

## Deposit Flow Steps

### 1. Authentication
- Verify cashier token from Authorization header
- Extract cashier username from JWT token

### 2. Validation
- Check phone number and amount are provided
- Validate amount is positive
- Normalize phone number format

### 3. Player Lookup
- Find player by normalized phone number
- Return error if player not found

### 4. Cashier Lookup
- Find cashier by username
- Return error if cashier not found

### 5. Balance Calculation
- **Player Balance Update**: 100% of deposit amount goes to `non_withdrawable` balance
- **Cashier Balance**: Decrease by deposit amount

```javascript
// Before Deposit
oldPlayerBalance = player.balance
oldNonWithdrawable = player.non_withdrawable
oldWithdrawable = player.withdrawable

// After Deposit
newNonWithdrawable = oldNonWithdrawable + amount  // 100% to non-withdrawable
newWithdrawable = oldWithdrawable               // No change
newPlayerBalance = newNonWithdrawable + newWithdrawable + player.bonus_balance

oldCashierBalance = cashier.balance
newCashierBalance = oldCashierBalance - amount
```

### 6. Database Updates (Transaction)

#### Update Players Table
```sql
UPDATE players 
SET balance = ?, withdrawable = ?, non_withdrawable = ?, updated_at = CURRENT_TIMESTAMP
WHERE id = ?
```

#### Update Cashier_Users Table
```sql
UPDATE cashier_users 
SET balance = ?, updated_at = CURRENT_TIMESTAMP
WHERE id = ?
```

#### Insert into Transactions Table
```sql
INSERT INTO transactions (phonenumber, method, status, time, old_balance, new_balance)
VALUES (?, 'cash', 'deposit', CURRENT_TIMESTAMP, ?, ?)
```

#### Insert into Cashier_Transactions Table
```sql
INSERT INTO cashier_transactions (cashier_id, player_id, transaction_type, amount, balance_before, balance_after, status)
VALUES (?, ?, 'deposit', ?, ?, ?, 'completed')
```

### 7. Real-time Notification
- Send balance update notification to player's betting app
- Include all relevant balance information

### 8. Response
Return success response with:
- Updated player information
- New cashier balance
- Deposit amount and split details

## API Endpoint

**POST** `/api/cashier/playerlist/deposit`

**Headers:**
- `Authorization: Bearer <token>`

**Body:**
```json
{
  "phoneNumber": "+251912345678",
  "amount": 100
}
```

**Response:**
```json
{
  "status": "success",
  "message": "Deposit successful",
  "data": {
    "player": {
      "id": 1,
      "name": "johndoe",
      "username": "johndoe",
      "phoneNumber": "+251912345678",
      "balance": 100,
      "withdrawable": 0,
      "non_withdrawable": 100,
      "bonus_balance": 0,
      "status": "active"
    },
    "cashier_balance": 4900,
    "deposit_amount": 100,
    "deposit_split": {
      "withdrawable": 0,
      "non-withdrawable": 100,
      "total": 100
    }
  }
}
```

## Key Features

✅ **Authentication**: Proper JWT token verification  
✅ **Data Integrity**: All tables updated consistently  
✅ **Balance Tracking**: Separate withdrawable and non-withdrawable balances  
✅ **Transaction History**: Complete audit trail in both transaction tables  
✅ **Real-time Updates**: Notifications sent to player app  
✅ **Error Handling**: Comprehensive validation and error responses  
✅ **Foreign Keys**: Proper relationships between tables  

## Withdrawal Flow

The withdrawal function follows a similar pattern but:
- Only withdraws from `withdrawable` balance
- Increases cashier balance
- Uses 'withdrawal' transaction type
- Validates player was created by the cashier

Both functions ensure complete data consistency across all database tables.
