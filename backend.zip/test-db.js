const { dbManager } = require('./src/database/databaseManager.js');

async function testDB() {
  try {
    await dbManager.connect();
    const sqlite = dbManager.getSQLite();
    
    console.log('📊 Testing database connection...');
    
    // Check users table
    const users = await sqlite.all('SELECT id, username, phone_number FROM users LIMIT 5');
    console.log('👥 Users table:', users);
    
    // Check players table  
    const players = await sqlite.all('SELECT id, username, phone_number FROM players LIMIT 5');
    console.log('🎮 Players table:', players);
    
    await dbManager.disconnect();
  } catch (error) {
    console.error('❌ Database test error:', error);
  }
}

testDB();
