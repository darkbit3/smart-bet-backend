# Cashout Agent Table - Summary

## ✅ Table Created Successfully

### Table Name: `cashout_agent`

### Schema:
```sql
CREATE TABLE cashout_agent (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  withdraw_player TEXT NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  cashier_name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'failed', 'cancelled')),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### Columns:
| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Unique identifier |
| `withdraw_player` | TEXT | NOT NULL | Player who requested withdrawal |
| `amount` | DECIMAL(10,2) | NOT NULL | Withdrawal amount |
| `cashier_name` | TEXT | NOT NULL | Cashier processing the withdrawal |
| `status` | TEXT | NOT NULL DEFAULT 'pending' | Status of withdrawal |
| `created_at` | DATETIME | DEFAULT CURRENT_TIMESTAMP | When record was created |
| `updated_at` | DATETIME | DEFAULT CURRENT_TIMESTAMP | When record was last updated |

### Status Values:
- `pending` - Withdrawal requested, not yet processed
- `completed` - Withdrawal successfully processed
- `failed` - Withdrawal processing failed
- `cancelled` - Withdrawal was cancelled

### Indexes Created:
- `idx_cashout_agent_cashier` - For filtering by cashier_name
- `idx_cashout_agent_status` - For filtering by status
- `idx_cashout_agent_player` - For filtering by withdraw_player
- `idx_cashout_agent_created_at` - For time-based queries

## 🗄️ Database Integration

### Location in Database:
- File: `data/smart-betting.db`
- Table Count: 15 tables total
- Current Records: 0 (ready for use)

### Related Tables:
- `players` - For player information
- `cashier_users` - For cashier authentication
- `transactions` - For transaction history
- `cashier_transactions` - For cashier-specific transactions

## 💡 Usage Examples

### Insert a new cashout request:
```sql
INSERT INTO cashout_agent (withdraw_player, amount, cashier_name, status)
VALUES ('+251912345678', 500.00, 'kaleab', 'pending');
```

### Update status to completed:
```sql
UPDATE cashout_agent 
SET status = 'completed', updated_at = CURRENT_TIMESTAMP 
WHERE id = 1;
```

### Query pending withdrawals for a cashier:
```sql
SELECT * FROM cashout_agent 
WHERE cashier_name = 'kaleab' AND status = 'pending'
ORDER BY created_at DESC;
```

### Get all withdrawals for a player:
```sql
SELECT * FROM cashout_agent 
WHERE withdraw_player = '+251912345678'
ORDER BY created_at DESC;
```

## 🔗 Next Steps

The table is ready for integration with:
1. **Backend API** - Create endpoints for CRUD operations
2. **Frontend UI** - Build interface for managing cashouts
3. **Business Logic** - Implement cashout processing workflow
4. **Validation** - Add rules for amount limits, player eligibility

The `cashout_agent` table is now ready to track withdrawal operations in your smart betting system! 🚀
