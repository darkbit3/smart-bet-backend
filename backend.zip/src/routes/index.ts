import { Router } from 'express';
import loginRoutes from './login.routes';
import registerRoutes from './register.routes';
import availabilityRoutes from './availability.routes';
import balanceRoutes from './balance.routes';
import userRoutes from './user.routes';
import passwordRoutes from './password.routes';
import transactionRoutes from './transaction.routes';
import balanceApiRoutes from './balance-api.routes';
import voucherRoutes from './voucher.routes';
import { createCashoutAgentRoutes } from './cashoutAgent.routes';
import { SQLiteDatabase } from '../database/sqlite';
import { dbManager } from '../database/databaseManager';

const router = Router();

// Mount login routes
router.use('/', loginRoutes);

// Mount register routes
router.use('/', registerRoutes);

// Mount availability routes
router.use('/availability', availabilityRoutes);

// Mount player routes (including balance)
router.use('/player', balanceRoutes);

// Mount user routes
router.use('/user', userRoutes);

// Mount password routes
router.use('/password', passwordRoutes);

// Mount transaction routes
router.use('/transaction', transactionRoutes);

// Mount balance API routes
router.use('/balance-api', balanceApiRoutes);

// Mount voucher routes
router.use('/voucher', voucherRoutes);

// Mount cashout agent routes (will be initialized lazily)
const cashoutAgentRoutes = createCashoutAgentRoutes(null as any);
router.use('/cashout-agent', cashoutAgentRoutes);

// Set database reference when available
setTimeout(() => {
  try {
    if (dbManager.isDBConnected()) {
      const rawDb = dbManager.getSQLite().getRawDatabase();
      if (rawDb && (cashoutAgentRoutes as any).setDatabase) {
        (cashoutAgentRoutes as any).setDatabase(rawDb);
        console.log('✅ Cashout agent database reference set from routes');
      }
    }
  } catch (error) {
    console.error('❌ Failed to set cashout agent database reference:', error);
  }
}, 1000);

export { createCashoutAgentRoutes } from './cashoutAgent.routes';

export default router;
