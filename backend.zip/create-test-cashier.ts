import { dbManager } from './src/database/databaseManager';
import { hash } from 'bcrypt';

async function createTestCashier() {
  try {
    // Connect to database
    await dbManager.connect();
    console.log('Connected to database');

    // Create test cashier with hashed password
    const password = 'admin123'; // Test password
    const hashedPassword = await hash(password, 10);
    
    const sqlite = dbManager.getSQLite();
    
    // Insert test cashier
    const result = await sqlite.run(
      `INSERT OR REPLACE INTO cashier_users 
       (username, password_hash, created_by, number_of_players, balance, status) 
       VALUES (?, ?, ?, ?, ?, ?)`,
      ['kaleab', hashedPassword, 'system', 0, 6000, 'active']
    );

    console.log('✅ Test cashier created successfully!');
    console.log('Username: kaleab');
    console.log('Password: admin123');
    console.log('Balance: 6000');
    console.log('Insert result:', result);

  } catch (error) {
    console.error('❌ Error creating test cashier:', error);
  } finally {
    await dbManager.disconnect();
    process.exit(0);
  }
}

createTestCashier();
